<?php
require 'function.php';
require 'DBconf.php';   //funzione per la configurazione
$config= require 'database_conf.php'; //così non scriviamo tutto dentro
$db = DBconf::getDB($config);   //ora si trova dentro la funzione




//============READ===========

$query="select * from studenti";
try {
    //prepara la query da una stringa
    $stm=$db->prepare($query);
    $stm->execute();

//useremo un while per leggere le tuple/record (non i campi)
//Per prendere i campi facciamo in modo che le tuple sono degli oggetti e ogni campo corrisponde ad un attributo dell'oggetto

//finche dentro "student" c'è qualcosa lo stampa
//ogni giro del while tira fuori i valori da ogni tupla
//alla fine su "student" scrive "false" ed esce dal while
    while ($student=$stm->fetch()){
        echo "matricola_studente: ".$student->matricola_studente."<br>";
        echo "nome: ".$student->nome."<br>";
        echo "cognome: ".$student->cognome."<br>";
        echo "data_iscrizione: ".$student->data_iscrizione."<br>";
        echo "media: ".$student->media."<br>";
        echo "<hr>";
    }
    $stm->closeCursor();    //chiude la connessione
}catch (EXCEPTION $eccezzione){
    echo "<br>";
    logError($eccezzione);
    echo $eccezzione->getMessage(); //per riportare l'eccezzione
}



//=================READ complessa============
/*
$query="select nome,media from studenti where nome=:name";

try {
    $stm=$db->prepare($query);
    $stm->bindValue(":name","Azzurra");
    $stm->execute();
    while ($student=$stm->fetch()){
        echo "nome: ".$student->nome."<br>";
        echo "media: ".$student->media."<br>";
    }
    $stm->closeCursor();
}catch (Exception $eccezzione){
    echo "<br>";
    logError($eccezzione);
}

*/



//================CREATE========================
/*
$query="insert into studenti (matricola_studente,nome,cognome,data_iscrizione,media)
values (:matricola,:nome,:cognome,now(),:media)";   //la funzione "now()" sostituisce "data_iscrizione"
try {
    $stm=$db->prepare($query);
    $stm->bindValue(":matricola","00500");
    $stm->bindValue(":nome","Lucy");
    $stm->bindValue(":cognome","Catanzaro");
    $stm->bindValue(":media","2");

    if ($stm->execute()){
        $stm->closeCursor();
    }else{
        throw new PDOException("errore nella query");
    }
}catch (Exception $eccezzione){
    logError($eccezzione);
}
*/


//=======================UPDATE=========================
/*
$query="update studenti set media=:media,nome=:nome";
try {
    $stm=$db->prepare($query);
    $stm->bindValue(":nome","Lucy");
    $stm->bindValue(":media","4");
    $stm->execute();
    $stm->closeCursor();
}catch (Exception $eccezzione){
    logError($eccezzione);
}
*/



//=======================DELETE=========================

$query="delete from studenti where nome=:nome";
try {
    $stm=$db->prepare($query);
    $stm->bindValue(":nome","Lucy");
    $stm->execute();
    $stm->closeCursor();
}catch (Exception $eccezzione){
    logError($eccezzione);
}





